package threeChess;

/**
 * Enumeration the player colours
 **/
public enum Colour{BLUE,GREEN,RED;}
