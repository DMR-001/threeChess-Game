package threeChess;

/**
 * Enumeration of the rectilinear directions
 * used as the basis for all moves.
 **/
public enum Direction{FORWARD,BACKWARD,LEFT,RIGHT;}

